/* Meus Jogos Retrô - sw.js
   Guarda o aplicativo e o emulador no aparelho para funcionar sem internet.
   Coloque este arquivo na mesma pasta do MeusJogosRetro.html. */
const VERSAO = 'mjr-v2';
const BASICO = ['./', 'MeusJogosRetro.html'];
const EMULADOR = [
  "emulatorjs/data/compression/extract7z.js",
  "emulatorjs/data/compression/extractzip.js",
  "emulatorjs/data/compression/libunrar.js",
  "emulatorjs/data/compression/libunrar.wasm",
  "emulatorjs/data/cores/fceumm-legacy-wasm.data",
  "emulatorjs/data/cores/fceumm-wasm.data",
  "emulatorjs/data/cores/genesis_plus_gx-legacy-wasm.data",
  "emulatorjs/data/cores/genesis_plus_gx-wasm.data",
  "emulatorjs/data/cores/mupen64plus_next-legacy-wasm.data",
  "emulatorjs/data/cores/mupen64plus_next-wasm.data",
  "emulatorjs/data/cores/reports/fceumm.json",
  "emulatorjs/data/cores/reports/genesis_plus_gx.json",
  "emulatorjs/data/cores/reports/mupen64plus_next.json",
  "emulatorjs/data/cores/reports/snes9x.json",
  "emulatorjs/data/cores/snes9x-legacy-wasm.data",
  "emulatorjs/data/cores/snes9x-wasm.data",
  "emulatorjs/data/emulator.min.css",
  "emulatorjs/data/emulator.min.js",
  "emulatorjs/data/loader.js",
  "emulatorjs/data/localization/en-US.json",
  "emulatorjs/data/localization/pt-BR.json",
  "emulatorjs/data/localization/retroarch.json",
  "emulatorjs/data/version.json"
];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(VERSAO);
    await Promise.allSettled(BASICO.map(u => c.add(new Request(u, {cache: 'reload'}))));
    await Promise.allSettled(EMULADOR.map(u => c.add(u)));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VERSAO && k.startsWith('mjr-')) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  const p = decodeURIComponent(url.pathname);
  if (p.includes('/Jogos/')) return; // ROMs, capas e listas de pastas: sempre direto do servidor

  // Emulador: primeiro o que está guardado
  if (p.includes('/emulatorjs/')) {
    e.respondWith((async () => {
      const c = await caches.open(VERSAO);
      const guardado = await c.match(req, {ignoreSearch: true});
      if (guardado) return guardado;
      const r = await fetch(req);
      if (r.ok && r.status === 200) c.put(req, r.clone());
      return r;
    })());
    return;
  }

  // Página e demais arquivos: tenta a rede e, sem ela, usa o que está guardado
  e.respondWith((async () => {
    const c = await caches.open(VERSAO);
    try {
      const r = await fetch(req);
      if (r.ok && r.status === 200) c.put(req, r.clone());
      return r;
    } catch (err) {
      const guardado = await c.match(req, {ignoreSearch: true});
      if (guardado) return guardado;
      if (req.mode === 'navigate') {
        const home = await c.match('MeusJogosRetro.html');
        if (home) return home;
      }
      throw err;
    }
  })());
});
